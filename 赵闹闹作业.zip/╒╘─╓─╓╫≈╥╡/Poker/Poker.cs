﻿using Poker.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poker
{
    public delegate void Message(string s);
    public class Poker:AbstractPoker
    {
        private event Message _ordinaryEvent;

        private event Message _successEvent;

        private event Message _failEvent;

        public int _count { get; set; }

        private List<AbstractUser> _users;
        public Poker(int count, params AbstractUser[] users)
        {
            _count = count;
            _users = new List<AbstractUser>();
            foreach (var user in users)
            {
                _users.Add(user);
                _ordinaryEvent += user.GetOrdinary;
                _successEvent += user.GetSuccess;
            }
        }
        public override void AddUser(AbstractUser user) {

            //有需要可以在此校验注册逻辑，判断用户是否合法
            if (_users.Contains(user))
            {
                return;
            }
            _users.Add(user);
            _ordinaryEvent += user.GetOrdinary;
            _successEvent += user.GetSuccess;
        }
        public override void GetPoker(AbstractUser user,int buyCount)
        {
            if (user!= null && !_users.Contains(user))
            {
                _ordinaryEvent?.Invoke(user.Name + "非注册玩家，禁止拿火柴");
                return;
            }
            if (_count<TriggerFailCount)//判断游戏有没有已经结束
            {
                _ordinaryEvent?.Invoke("当前火柴已经拿完，请换一个");
                return;
            }
            _count = _count- buyCount;
            if (_count > TriggerFailCount)//判断触发是否到达成功条件
            {
                _ordinaryEvent?.Invoke(user.Name+ "成功拿取了火柴");
            }
            else
            {
                _successEvent -= user.GetSuccess;
                _failEvent += user.GetFail;
                _successEvent?.Invoke("恭喜你成功了，失败者是"+user.Name);
                _failEvent?.Invoke("很遗憾，你取到最后一个失败了");
            }
        }

       

       
    }
}
