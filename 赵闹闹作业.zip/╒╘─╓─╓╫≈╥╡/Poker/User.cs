﻿using Poker.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poker
{
    public class User: AbstractUser
    {
       
        
        public User(string name)
        {
            Name = name;
        }

        
        /// <summary>
        /// 抽取火柴
        /// </summary>
        public override void GetCount(AbstractPoker poker,int count)
        {
            poker.GetPoker(this, count);
        }
        /// <summary>
        /// 普通消息
        /// </summary>
        /// <param name="message"></param>

        public override void GetOrdinary(string message)
        {
            Console.WriteLine(message);
            Message = message;
        }
        /// <summary>
        /// 接收成功消息
        /// </summary>
        /// <param name="message"></param>
        public override void GetSuccess(string message)
        {
            Message = message;
            Replay = true;
        }

        /// <summary>
        /// 接收失败消息
        /// </summary>
        /// <param name="message"></param>
        public override void GetFail(string message)
        {
            Message = message;
            Replay = true;
        }

       
    }
}
