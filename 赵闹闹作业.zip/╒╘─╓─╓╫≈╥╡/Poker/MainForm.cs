﻿using Poker.Abstract;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Poker
{
    public partial class MainForm : Form
    {
        AbstractPoker poker1  ;
        AbstractPoker poker2 ;
        AbstractPoker poker3;
        AbstractUser user1 ;
        AbstractUser user2;
      
        
        public MainForm()
        {
            InitializeComponent();
            user1 = new User("用户1");
            user2 = new User("用户2");
            poker1 = new Poker(3, user1, user2);
            poker2 = new Poker(5, user1, user2);
            poker3 = new Poker(7, user1, user2);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var buyCount = 0;
            try
            {
                 buyCount = Convert.ToInt32(txtb4.Text);
            }
            catch (Exception ex)
            {

                MessageBox.Show("请输入正整数");
                return;
            }
            if (buyCount<1)
            {
                MessageBox.Show("不能小与1");
                return;
            }
            
            SetUserGetCount(cbb1.SelectedIndex, user1, buyCount);
            button1.Enabled = false;
            if (user1.Replay || user2.Replay)
            {
                button2.Enabled = false;
            }
            else
            {
                button2.Enabled = true;
            }

        }
        private void button2_Click(object sender, EventArgs e)
        {
            var buyCount = 0;
            try
            {
                buyCount = Convert.ToInt32(txtb5.Text);
            }
            catch (Exception ex)
            {

                MessageBox.Show("请输入正整数");
                return;
            }
            if (buyCount < 1)
            {
                MessageBox.Show("不能小与1");
                return;
            }
            SetUserGetCount(cbb2.SelectedIndex, user2, buyCount);
            button2.Enabled = false;
            if (user1.Replay || user2.Replay)
            {
                button1.Enabled = false;
            }
            else
            {
                button1.Enabled = true;
            }
        }

        private void SetUserGetCount(int selectIndex, AbstractUser user,int buyCount) {
            if (selectIndex == 0)
            {
                user.GetCount(poker1, buyCount);
            }
            else if (selectIndex == 1)
            {
                user.GetCount(poker2, buyCount);
            }
            else if (selectIndex == 2)
            {
                user.GetCount(poker3, buyCount);
            }
            else
            {
                MessageBox.Show("没有匹配到Poker");
            }
            SetMessage();
        }

       

        private void Form1_Load(object sender, EventArgs e)
        {
            SetInit();
            txtMessageUser1.Text = "开始请准备";
            txtMessageUser2.Text = "开始请准备";
        }
        
        private void button4_Click(object sender, EventArgs e)
        {
            SetInit();
            txtMessageUser1.Text = "重新开始请准备";
            txtMessageUser2.Text = "重新开始请准备";
            button1.Enabled = true;
            button2.Enabled = true;
        }
        private void SetMessage()
        {

            txtMessageUser1.Text = user1.Message;
            txtMessageUser2.Text = user2.Message;

        }
        private void SetInit()
        {
            user1 = new User("用户1");
            user2 = new User("用户2");
            poker1 = new Poker(3, user1, user2);
            poker2 = new Poker(5, user1, user2);
            poker3 = new Poker(7, user1, user2);
            cbb1.SelectedIndex = 0;
            cbb2.SelectedIndex = 0;
            txtb1.Text = "3";
            txtb2.Text = "5";
            txtb3.Text = "7";
            txtb4.Text = "1";
            txtb5.Text = "1";
          
         
        }

        private void txtb4_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtb4_KeyDown(object sender, KeyEventArgs e)
        {
           
        }
    }
}
