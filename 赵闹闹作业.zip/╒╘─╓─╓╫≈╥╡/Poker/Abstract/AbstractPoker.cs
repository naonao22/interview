﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poker.Abstract
{
    public abstract class AbstractPoker
    {
        public  int TriggerFailCount=0;
        public abstract void AddUser(AbstractUser user);

        public abstract void GetPoker(AbstractUser user,int count);
    }
}
