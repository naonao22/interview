﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poker.Abstract
{
    public abstract class AbstractUser
    {
        /// <summary>
        /// 游戏消息总线
        /// </summary>
        public string Message { get; set; }
        public string Name { get; set; }

        public bool Replay { get; set; }


        /// <summary>
        /// 抽取火柴
        /// </summary>
        public abstract void GetCount(AbstractPoker poker,int count);
        /// <summary>
        /// 普通游戏信息处理
        /// </summary>

        public abstract void GetOrdinary(string message);
        /// <summary>
        /// 接收成功方法并处理
        /// </summary>
        public abstract void GetSuccess(string message);

        /// <summary>
        /// 接收失败方法并处理
        /// </summary>
        public abstract void GetFail(string message);
    }
}
